package notaAula03;

public class app {

    public static void main(String[] args) {
        
        cadastro c1 = new cadastro(227, "banana", 5);
        c1.Vender();
    }

}